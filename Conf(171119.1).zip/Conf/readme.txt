Conf Prpject Readme File
Version 171119.1
--------
Conf project written by SMALLSO in a flash, the overall code is not difficult to achieve, or relatively simple. The main focus on syntax and flexibility, grammar closer to high-level language (C + +), recommended to use VSCode or Notepad ++ for writing. You are welcome to amend and expand the conf source code.
--------
SMALLSO Studios.